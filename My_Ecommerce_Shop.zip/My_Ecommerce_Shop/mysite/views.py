from django.shortcuts import render
from django.http import HttpResponse
#from .models import Product, CartItem, Order

# Create your views here.
def index(request):
   # return HttpResponse('Welcome to me')
    my_dic = {'inserted': "Welcome, Our Online shop is coming soon......"}
    return render(request,"index.html",context=my_dic)
def product(request):
    return render(request, 'Product.html')
def about(request):
    return render(request, 'About.html')

def cart(request):
    return render(request, 'cart.html')

def checkout(request):
    return render(request, 'checkout.html')

def order(request):
    return render(request, 'order.html')


#BASIC PAGES


def contact(request):
    return render(request, 'contact.html')

def login(request):
    return render(request, 'login.html')

def laptop(request):
    return render(request, 'laptop.html')

def terms(request):
    return render(request, 'T&Cs.html')